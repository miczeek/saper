var indexSectionsWithContent =
{
  0: "abcdfginpstxy",
  1: "gpt",
  2: "s",
  3: "bcdginst",
  4: "acfgstxy",
  5: "s",
  6: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Pages"
};

