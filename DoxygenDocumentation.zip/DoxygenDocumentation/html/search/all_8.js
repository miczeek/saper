var searchData=
[
  ['newgame',['NewGame',['../class_saper_1_1_game.html#a77b5cf2c44e21908cbbe17622ef1c2db',1,'Saper::Game']]],
  ['newgametype',['NewGameType',['../class_saper_1_1_game.html#a1f14c9d69d6267494ca48f146c9e34c7',1,'Saper::Game']]]
];
