var searchData=
[
  ['game_5fheight',['game_height',['../class_saper_1_1_game.html#a4384a168c23e724b445de95a6af206ff',1,'Saper::Game']]],
  ['game_5fover',['game_over',['../class_saper_1_1_game.html#a34bdb6551f2f859d65cd424b97c48d74',1,'Saper::Game']]],
  ['game_5fsize',['game_size',['../class_saper_1_1_game.html#a784f5ee2db8e065581bea6885af146a9',1,'Saper::Game']]],
  ['game_5fwidth',['game_width',['../class_saper_1_1_game.html#ac555ca6b549cd5db36344c44d30f628d',1,'Saper::Game']]]
];
