var searchData=
[
  ['game',['Game',['../class_saper_1_1_game.html#a9d694a044fb311e088ce585b716a9d84',1,'Saper::Game']]],
  ['getfield',['getField',['../class_saper_1_1_game.html#a6ad3e962eca53c2dbf6b499a469fa5f2',1,'Saper::Game']]]
];
