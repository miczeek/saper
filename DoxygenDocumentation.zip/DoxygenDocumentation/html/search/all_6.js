var searchData=
[
  ['newgame',['NewGame',['../class_saper_1_1_game.html#ada46d1d0719becfbff58cd5ab3d502c6',1,'Saper::Game']]]
];
